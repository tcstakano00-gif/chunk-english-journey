"""English Journey v4.0.44 layout/regression checks; run from extracted ZIP with Playwright installed."""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'index.html').read_text('utf-8')
journey=(ROOT/'journey.js').read_text('utf-8')

def run():
    cases=0
    with sync_playwright() as pw:
        b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        try:
            for width in (375,390):
                page=b.new_page(viewport={'width':width,'height':844}, device_scale_factor=1)
                errors=[]
                page.on('pageerror',lambda error:errors.append(str(error)))
                page.set_content(html,wait_until='load')
                page.add_script_tag(content=journey)
                # Every learning mode remains available; game progress preserved.
                assert page.locator('.journey-home').count()==1;cases+=1
                page.evaluate("go('journey')")
                assert page.locator('.journey-stage').count()==10;cases+=1
                for mode in ('example','conversation'):
                    for position in (0,1):
                        page.evaluate(f"go('{mode}')")
                        page.locator('.popup-qa-trigger').nth(position).click()
                        page.wait_for_timeout(80)
                        def measure():
                            return page.evaluate("""() => {
                                let p=document.querySelector('.popup-qa.is-practice-pinned');
                                let panel=p?.querySelector('.study-popup');
                                let buttons=panel?.querySelectorAll('.popup-action-avatar');
                                return {y:window.scrollY,top:p?.getBoundingClientRect().top,height:panel?.getBoundingClientRect().height,
                                  first:document.querySelector('.popup-qa')===p,pinned:getComputedStyle(p).position,
                                  count:buttons?.length,avatars:[...(buttons||[])].map(el=>{
                                     let r=el.getBoundingClientRect();return [r.width,r.height]
                                  }),overflow:document.documentElement.scrollWidth>window.innerWidth};
                            }""")
                        before=measure()
                        assert before['first'] and before['pinned']=='sticky' and 0<=before['top']<=10,before;cases+=1
                        assert before['count']==2 and all(abs(w-h)<=1 for w,h in before['avatars']),before;cases+=1
                        assert not before['overflow'],before;cases+=1
                        page.evaluate('setMicrophoneLiveBanner(true)')
                        after=measure()
                        assert all(abs(before[k]-after[k])<=1 for k in ('y','top','height')), (before,after);cases+=1
                        assert page.locator('.study-popup-mic:not([hidden])').inner_text()=='マイクON中';cases+=1
                        assert page.locator('#microphoneLiveBanner').is_hidden();cases+=1
                        page.evaluate('setMicrophoneLiveBanner(false)')
                        page.screenshot(path=str(ROOT/'visual_baselines_v444'/f'{mode}_{position}_{width}.png'))
                page.evaluate("go('pron')")
                before=page.locator('.v4-chunk').bounding_box()
                page.evaluate('setMicrophoneLiveBanner(true)')
                after=page.locator('.v4-chunk').bounding_box()
                assert abs(before['y']-after['y'])<=1;cases+=1
                assert page.locator('.v4-pron-mic-state').is_visible() and page.locator('.v4-pron-mic-state').inner_text()=='マイクON中';cases+=1
                assert page.locator('#microphoneLiveBanner').is_hidden();cases+=1
                page.screenshot(path=str(ROOT/'visual_baselines_v444'/f'pron_mic_{width}.png'))
                assert not errors,errors;cases+=1
                page.close()
        finally: b.close()
    return cases

if __name__=='__main__':
    print(f'PASS {run()} / {run.__name__} checks')
