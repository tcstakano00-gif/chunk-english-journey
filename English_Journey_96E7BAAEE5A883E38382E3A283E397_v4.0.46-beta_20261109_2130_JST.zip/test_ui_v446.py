from pathlib import Path
from playwright.sync_api import sync_playwright
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import threading,functools, json
root='/mnt/data/v446_public'
server=ThreadingHTTPServer(('127.0.0.1',8896),functools.partial(SimpleHTTPRequestHandler,directory=root))
threading.Thread(target=server.serve_forever,daemon=True).start()
results=[]
def chk(name,x):
  results.append((name,bool(x)));assert x,name
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for width in [375,390]:
   ctx=browser.new_context(viewport={'width':width,'height':844},service_workers='block');page=ctx.new_page();err=[];page.on('pageerror',lambda e:err.append(str(e)))
   page.set_content(Path(root,'index.html').read_text(encoding='utf-8'),wait_until='load');page.add_script_tag(content=Path(root,'journey.js').read_text(encoding='utf-8'));page.wait_for_timeout(80)
   for mode in ['example','conversation']:
    page.evaluate(f"go('{mode}')");page.wait_for_timeout(70)
    sections=page.locator('.practice-content-card');chk(f'{width} {mode} has 2 cards',sections.count()==2)
    for i in range(2):
     im=sections.nth(i).locator('img.popup-title-avatar');chk(f'{width} {mode} image {i} exists',im.count()==1)
     im.evaluate("img=>{img.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2240%22 height=%2240%22%3E%3C/svg%3E'}")
     props=im.evaluate('img=>({ok:img.naturalWidth>0&&img.naturalHeight>0,box:img.getBoundingClientRect().toJSON(),radius:getComputedStyle(img).borderRadius,src:img.currentSrc})')
     chk(f'{width} {mode} image {i} asset referenced',bool(props['src']))
     chk(f'{width} {mode} image {i} square',abs(props['box']['width']-props['box']['height'])<1)
    chk(f'{width} {mode} default question selected',sections.nth(0).get_attribute('aria-pressed')=='true')
    sections.nth(1).click(force=True);chk(f'{width} {mode} card answer selects',sections.nth(1).get_attribute('aria-pressed')=='true' and page.locator('[data-choose="answer"]').get_attribute('aria-pressed')=='true')
    page.locator('[data-choose="question"]').click(force=True);chk(f'{width} {mode} question button selects',sections.nth(0).get_attribute('aria-pressed')=='true')
    page.locator('.practice-content-card').nth(1).focus();page.keyboard.press('Enter');chk(f'{width} {mode} keyboard selects',sections.nth(1).get_attribute('aria-pressed')=='true')
    if mode=='conversation':
     elements=page.evaluate('''() => {let root=document.querySelector('.v4-screen');return [...root.children].filter(e=>e.matches('.practice-content-card,.scene-compact')).map(e=>e.className)}''')
     chk(f'{width} scene after answer',len(elements)>=3 and 'practice-content-card' in elements[0] and 'practice-content-card' in elements[1] and 'scene-compact' in elements[2])
     scene=page.locator('.scene-choice button');chk(f'{width} scene buttons',scene.count()>=2);scene.nth(1).click();chk(f'{width} scene recomputed avatar',page.locator('.practice-content-card img.popup-title-avatar').count()==2)
   chk(f'{width} no JS errors',not err)
   ctx.close()
  browser.close()
except Exception as e:
 print('FAIL',repr(e))
finally:
 server.shutdown()
print('Tests',len(results),'PASS',sum(x[1] for x in results));print(json.dumps(results,ensure_ascii=False,indent=2))
