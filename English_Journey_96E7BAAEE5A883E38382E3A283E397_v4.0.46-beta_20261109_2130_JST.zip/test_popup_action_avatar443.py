"""Regression for actual popup action-button avatar circles, not heading avatars."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parent
report=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(375,812),(390,844)]:
  page=b.new_page(viewport={'width':width,'height':height},is_mobile=True,has_touch=True,device_scale_factor=1)
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content((root/'index.html').read_text(),wait_until='domcontentloaded')
  page.add_script_tag(content=(root/'journey.js').read_text())
  for mode in ('example','conversation'):
   page.evaluate('(m)=>go(m)',mode)
   for kind in (('exampleQuestion','example') if mode=='example' else ('question','reply')):
    page.evaluate('(k)=>toggleStudyPopup(k)',kind)
    popup=page.locator(f'.popup-qa[data-popup-kind="{kind}"] .study-popup')
    assert popup.is_visible(),(width,kind)
    avatars=popup.locator('.popup-action-avatar')
    assert avatars.count()==2,(width,kind,avatars.count())
    labels=['お手本の人物アイコン','学習者の人物アイコン']
    for i in range(2):
     avatar=avatars.nth(i)
     box=avatar.bounding_box()
     data=avatar.evaluate('''e=>{let c=getComputedStyle(e),b=e.getBoundingClientRect();return {width:b.width,height:b.height,radius:c.borderRadius,fit:c.backgroundSize,image:c.backgroundImage,flex:c.flex,tag:e.tagName}}''')
     assert box and abs(box['width']-box['height'])<=0.5,(width,kind,i,box)
     assert 23<=box['width']<=29,(width,kind,i,box)
     assert data['radius']=='50%',(width,kind,i,data)
     assert data['fit']=='cover',(width,kind,i,data)
     assert data['image'].startswith('url('),(width,kind,i,data)
     assert avatar.get_attribute('aria-label')==labels[i]
    h_before=popup.bounding_box()['height']
    scroll_before=page.evaluate('window.scrollY')
    page.evaluate('''() => {syncStudyPopupMic(true); const label=document.querySelector('.study-popup:not([hidden]) .mic-button-label'); if(label)label.textContent='聴取中';}''')
    h_after=popup.bounding_box()['height']
    assert abs(h_before-h_after)<1,(width,kind,'height changed',h_before,h_after)
    assert abs(scroll_before-page.evaluate('window.scrollY'))<1,(width,kind,'scroll changed')
    page.evaluate('syncStudyPopupMic(false)')
    report.append({'viewport':width,'mode':mode,'kind':kind,'avatars':'2 square circles','popup_height':'stable','scroll':'stable'})
    page.evaluate('closeStudyPopup()')
   if mode=='example':
    page.screenshot(path=str(root/f'example_popup_actions_{width}_v443.png'))
  assert not errors,errors
  page.close()
 b.close()
(root/'TEST_REPORT_ACTION_AVATARS_V443.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('PASS',len(report),'popup states; two action avatars validated each')
