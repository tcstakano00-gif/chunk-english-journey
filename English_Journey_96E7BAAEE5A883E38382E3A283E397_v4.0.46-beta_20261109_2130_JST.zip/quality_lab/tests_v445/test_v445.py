from pathlib import Path
from playwright.sync_api import sync_playwright
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import threading,os,json
ROOT=Path('/mnt/data/v445')
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT),**kwargs)
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
URL=f'http://127.0.0.1:{server.server_port}/index.html'
results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(375,812),(390,844)]:
  page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1,has_touch=True,is_mobile=True)
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content((ROOT/'index.html').read_text(encoding='utf8'),wait_until='load');page.add_script_tag(content=(ROOT/'journey.js').read_text(encoding='utf8'));page.wait_for_timeout(300)
  for mode in ['example','conversation','pron']:
   page.evaluate(f"go('{mode}')");page.wait_for_timeout(100)
   rail=page.locator('#practiceActionDock');assert rail.count()==1,(width,mode,'missing rail')
   assert page.locator('.practice-action-row button').count()==3
   assert [v.strip() for v in page.locator('.practice-action-row button').all_inner_texts()]==['発音','■ 停止','お手本'],(width,mode,'action labels')
   if mode!='pron':
    cards=page.locator('.practice-content-card');assert cards.count()==2
    assert cards.nth(0).get_attribute('data-popup-kind') in ['exampleQuestion','question']
    assert cards.nth(0).evaluate("e=>e.classList.contains('is-practice-selected')")
    assert not cards.nth(1).evaluate("e=>e.classList.contains('is-practice-selected')")
    page.locator('[data-choose=answer]').click();assert cards.nth(1).evaluate("e=>e.classList.contains('is-practice-selected')")
    target=page.locator('#practiceMicButton').get_attribute('data-mic-kind');assert target in ['example','reply']
    page.locator('[data-choose=question]').click();assert cards.nth(0).evaluate("e=>e.classList.contains('is-practice-selected')")
   mic=page.locator('#practiceMicButton')
   railbefore=rail.bounding_box();scrollbefore=page.evaluate('window.scrollY')
   page.evaluate("setMicIndicator(true,document.getElementById('practiceMicButton').dataset.micKind)")
   page.wait_for_timeout(30)
   railafter=rail.bounding_box();scrollafter=page.evaluate('window.scrollY')
   assert abs(railafter['y']-railbefore['y'])<1,(width,mode,'rail jumped',railbefore,railafter)
   assert abs(railafter['height']-railbefore['height'])<1,(width,mode,'rail height changed')
   assert abs(scrollafter-scrollbefore)<1,(width,mode,'scroll jumped')
   assert page.locator('.practice-mic-status').evaluate("e=>e.classList.contains('is-mic-live')")
   assert mic.locator('.mic-button-label').inner_text()=='聞取中'
   for av in page.locator('.practice-action-row .popup-action-avatar').all():
    rect=av.bounding_box();assert abs(rect['width']-rect['height'])<1,('oval avatar',mode,rect)
   page.evaluate('restoreMicButtonIdle()');assert mic.locator('.mic-button-label').inner_text()=='発音'
   assert not page.locator('.practice-mic-status').evaluate("e=>e.classList.contains('is-mic-live')")
   assert page.evaluate('document.documentElement.scrollWidth <= innerWidth+1'),(width,mode,'overflow')
   page.screenshot(path=f'/mnt/data/v445/SCREEN_{mode}_{width}.png')
   results.append({'width':width,'mode':mode,'status':'PASS','rail_top':round(railafter['y'],1),'rail_height':round(railafter['height'],1)})
  page.evaluate("go('journey')")
  assert page.locator('.journey-stage-heading').count()>=5
  results.append({'width':width,'mode':'journey','status':'PASS'})
  page.evaluate("go('settings')")
  assert page.locator('#settingsBackup').count()==1
  results.append({'width':width,'mode':'settings','status':'PASS'})
  if errs:print('errors',errs)
  page.close()
 browser.close()
server.shutdown()
print(json.dumps(results,ensure_ascii=False,indent=2))
