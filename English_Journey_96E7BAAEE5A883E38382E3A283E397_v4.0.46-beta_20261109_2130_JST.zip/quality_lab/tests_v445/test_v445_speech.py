from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path('/mnt/data/v445');s=(root/'index.html').read_text();j=(root/'journey.js').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':390,'height':844})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(s,wait_until='load');page.add_script_tag(content=j)
 page.evaluate('''() => {
  window.testSpeech=[];
  window.SpeechRecognition=class {
   constructor(){window.testSpeech.push(this)}
   start(){this.onstart&&this.onstart()}
   stop(){this.onend&&this.onend()}
   abort(){this.onend&&this.onend()}
  }
 }''')
 for mode in ['example','conversation','pron']:
  page.evaluate(f"go('{mode}')")
  if mode!='pron':page.evaluate("selectPracticeTarget('answer')")
  val=page.locator('#practiceMicButton').get_attribute('data-mic-kind')
  page.evaluate('listen(practiceKind())')
  assert page.locator('.practice-mic-status').evaluate("e=>e.classList.contains('is-mic-live')")
  page.evaluate('''() => {const r=window.testSpeech.at(-1);r.onresult({results:[Object.assign([{transcript:'Sounds good to me.'}],{isFinal:true})]});}''')
  page.wait_for_timeout(40)
  assert page.evaluate('state.page')=='results',(mode,page.evaluate('state.page'))
  assert page.evaluate('state.latest.kind')==val
  print(mode,'score',page.evaluate('state.latest.score'),'kind',val)
  page.evaluate(f"go('{mode}')")
  page.evaluate('listen(practiceKind())')
  page.evaluate('finishListening()')
  assert page.locator('#practiceMicButton').get_attribute('aria-pressed')=='false'
  print(mode,'manual stop ok')
 assert not errors,errors
 b.close()
