#!/usr/bin/env python3
"""Build reproducible speech-signal fixtures. These are NOT speech-recognition ground truth.
Requires numpy, scipy, and locally installed espeak/espeak-ng (only for regeneration).
"""
import hashlib, io, json, math, shutil, subprocess, wave
from pathlib import Path
import numpy as np
from scipy.signal import resample_poly
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'audio'; OUT.mkdir(exist_ok=True)
SR=16000
UTTERANCES=[('sounds_good','Sounds good.'),('not_yet','Not yet.'),('how_about_you','How about you.'),('sounds_bad','Sounds bad.')]

def wav_bytes(signal):
    signal=np.asarray(signal,dtype=np.float64)
    pcm=np.rint(np.clip(signal,-1,1)*32767).astype('<i2')
    buf=io.BytesIO()
    with wave.open(buf,'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes(pcm.tobytes())
    return buf.getvalue()

def espeak(text):
    cmd=shutil.which('espeak-ng') or shutil.which('espeak')
    if not cmd:raise RuntimeError('espeak/espeak-ng is required to regenerate fixtures')
    raw=subprocess.check_output([cmd,'-v','en-us','-s','145','--stdout',text],stderr=subprocess.DEVNULL)
    with wave.open(io.BytesIO(raw),'rb') as w:
        x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float64)/32768
        x=resample_poly(x,SR,w.getframerate()) if w.getframerate()!=SR else x
    x=x/(max(np.max(np.abs(x)),.001))*.68
    return x

def signal_stats(x):
    x=np.asarray(x); rms=float(np.sqrt(np.mean(x*x))) if x.size else 0
    return {'duration_ms':round(x.size/SR*1000), 'rms':round(rms,5),'peak':round(float(np.max(np.abs(x))) if x.size else 0,5)}

def write(name,x,expected,condition,description):
    file=OUT/(name+'.wav');data=wav_bytes(x);file.write_bytes(data)
    return {'file':'audio/'+file.name,'expected_text':expected,'condition':condition,'description':description,
            'sha256':hashlib.sha256(data).hexdigest(),**signal_stats(np.clip(x,-1,1))}

def main():
    rng=np.random.default_rng(422)
    rows=[]
    silence=np.zeros(SR*3)
    rows.append(write('silence_3s',silence,'','silence','3-second silence; app should time out and recover'))
    for ident,text in UTTERANCES:
        base=espeak(text)
        if ident=='sounds_good':
            options=[('normal',base,'standard TTS voice'),('quiet',base*.12,'low volume'),('loud',base*1.32,'high volume'),
                     ('slow',resample_poly(base,5,4),'slower playback'),('fast',resample_poly(base,4,5),'faster playback'),
                     ('noise',np.clip(base+rng.normal(0,.055,len(base)),-1,1),'added broadband noise'),
                     ('delay',np.concatenate([np.zeros(SR*2),base]),'2s delay before speaking'),
                     ('truncated',base[:max(1,len(base)//2)],'speech cut off halfway'),
                     ('clipped',np.clip(base*3,-.8,.8),'clipped/limited speech'),]
        else:
            options=[('normal',base,'standard TTS voice'),('noise',np.clip(base+rng.normal(0,.055,len(base)),-1,1),'added broadband noise'),
                     ('fast',resample_poly(base,4,5),'faster playback')]
        for cond,sig,desc in options:
            rows.append(write(ident+'_'+cond,sig,text,cond,desc))
    meta={'schema':1,'purpose':'Signal-condition and application-flow regression, NOT validation of iOS recognition accuracy',
          'provenance':'Locally synthesized English phrases using espeak; no downloaded, copyrighted online recordings are bundled',
          'sample_rate':SR,'format':'mono 16-bit PCM WAV','generation_seed':422,'cases':rows}
    (ROOT/'manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'generated {len(rows)} files, {sum((OUT/r["file"].split("/")[-1]).stat().st_size for r in rows)//1024} KiB')
if __name__=='__main__':main()
