#!/usr/bin/env python3
"""Run independent regression suites; distinguish PASS / FAIL / NOT_RUN."""
from pathlib import Path
import json, subprocess, sys, time
ROOT=Path(__file__).resolve().parent.parent
SUITES=[('waveform', [sys.executable,'quality_lab/verify_audio.py']),
        ('javascript',[ 'node', 'verify.js']),
        ('browser', [sys.executable,'browser_tests.py'])]
results=[]
for name,command in SUITES:
    start=time.monotonic()
    try:
        p=subprocess.run(command,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
        result='PASS' if p.returncode==0 else 'FAIL'
        evidence=(p.stdout+'\n'+p.stderr)[-12000:]
    except (FileNotFoundError,ImportError) as e:
        result='NOT_RUN';evidence=str(e)
    except subprocess.TimeoutExpired as e:
        result='FAIL';evidence=f'Exceeded 90-second timeout: {e}'
    results.append({'suite':name,'status':result,'seconds':round(time.monotonic()-start,1),'output_tail':evidence})
summary={'version':'4.0.22','scope':'WAV signal + simulated speech events + Chromium UI; iPhone microphone and Safari ASR not tested', 'results':results}
(ROOT/'quality_lab'/'suite-report.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for r in results:print(r['suite'],r['status'],f"{r['seconds']}s")
raise SystemExit(1 if any(r['status']=='FAIL' for r in results) else 0)
