#!/usr/bin/env python3
"""Verify WAV content properties, fixture provenance, and condition coverage, without pretending to run ASR."""
import hashlib,json,math,wave
from pathlib import Path
from contextlib import closing
import numpy as np
ROOT=Path(__file__).resolve().parent

def verify():
    man=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    checks=[]
    def check(cond,msg):
        if not cond:raise AssertionError(msg)
        checks.append(msg)
    cases=man['cases'];check(len(cases)>=18,'>=18 waveform cases')
    conditions={r['condition'] for r in cases}
    check({'silence','normal','quiet','loud','slow','fast','noise','delay','truncated','clipped'}<=conditions,'10 signal conditions')
    for r in cases:
        f=(ROOT/r['file']).resolve()
        check(f.is_relative_to(ROOT.resolve()) and f.is_file(),'exists '+r['file'])
        data=f.read_bytes();check(hashlib.sha256(data).hexdigest()==r['sha256'],'checksum '+r['file'])
        with closing(wave.open(str(f),'rb')) as w:
            check((w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,16000),'PCM format '+r['file'])
            x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float64)/32768
        rms=math.sqrt(float(np.mean(x*x)))
        if r['condition']=='silence':check(rms<.00001,'silence RMS')
        else:check(rms>.001,'audible RMS '+r['file'])
        check(abs(round(len(x)/16)-r['duration_ms'])<=1,'duration '+r['file'])
    ref={r['condition']:r for r in cases if r['file'].startswith('audio/sounds_good_')}
    check(ref['quiet']['rms']<ref['normal']['rms']*.2,'quiet < normal amplitude')
    check(ref['fast']['duration_ms']<ref['normal']['duration_ms'],'fast duration shorter')
    check(ref['slow']['duration_ms']>ref['normal']['duration_ms'],'slow duration longer')
    check(ref['delay']['duration_ms']>=ref['normal']['duration_ms']+1990,'delay 2 seconds')
    check(ref['truncated']['duration_ms']<ref['normal']['duration_ms']*.6,'truncation')
    output={'type':'waveform-validation','scope':'audio signal integrity / reproducibility, no actual recognition engine',
            'cases':len(cases),'assertions':len(checks),'status':'PASS'}
    (ROOT/'waveform-report.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,ensure_ascii=False))
if __name__=='__main__':verify()
