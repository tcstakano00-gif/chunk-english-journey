# English Journey v4.0.43 β — テスト結果

- `test_popup_action_avatar443.py`: PASS（375×812/390×844、例文学習/AI会話、質問/回答の計8状態。各2個の操作アイコンの正円サイズ、背景画像指定、マイク状態変更後のポップアップ高さ・スクロール位置を確認）
- `browser_tests.py`: **27/27 PASS**（初期版番号検証と、旧アイコンDOM構成に依存する判定を現行UIに更新）
- `test_journey431.py`: PASS
- `test_popup432.py`: PASS
- `test_compact433.py`: PASS
- `test_swipe_avatar442.py`: PASS

## 注意点
Chrome/ChromiumによるDOM・CSS自動試験です。iOS Safariでの最終的な表示および音声認識は実機検証が必要です。スクリーンショットについては自動試験環境のセキュリティ制限によりローカルHTTP画像の取得を検証できていないため、画像読み込みまで含む実機確認を推奨します。
